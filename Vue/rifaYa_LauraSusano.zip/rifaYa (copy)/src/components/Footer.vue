<template>
  <q-footer elevated class="footer">
    <q-toolbar>
      <q-toolbar-title class="text-center text-bold">RifaYa</q-toolbar-title>
    </q-toolbar>
  </q-footer>
</template>

<script></script>

<style>
.footer {
  background-color: #2B7A78;
}
</style>
