<template>
    <Layout></Layout>
</template>
<script setup>
import Layout from "./components/Layout.vue";
</script>

<style lang="sass">
@import './assets/icomoon/style.css'

</style>
